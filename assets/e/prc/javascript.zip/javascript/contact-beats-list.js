Ext.namespace('prc.contact.beatslist');

var hanContactBeatList = function(btn)
{
}
