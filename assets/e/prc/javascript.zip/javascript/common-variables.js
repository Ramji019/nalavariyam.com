var commonMessages =
{
    NO_RESULTS_FOUND: "No Data retrieved matching your search criteria. Please try again later." 
}
var commonConfig = 
{
	OUTLET_ROW_COUNT: 500,
	OPPORTUNITY_ROW_COUNT: 200,
	CONTACT_ROW_COUNT: 50
};