var storContactDesignation = new Ext.data.ArrayStore(
{
	data: 
	[
		['D1', 'Editor in Chief'], ['D2', 'Creative Director'], ['D3', 'Managing Editor'], ['D4', 'Executive Editor'], ['D5', 'Senior Editor'], ['D6', 'Editorial Freelancer'], ['D7', 'Executive Content Producer'], ['D8', 'Director'], ['D9', 'Vice President'], ['D10', 'Development Manager'], ['D11', 'Editor']
	],
	fields: ['id', 'name']
});
