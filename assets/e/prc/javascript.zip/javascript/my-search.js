Ext.namespace('prc.shortcuts.mysearch');

var hanMySearch = function(btn)
{
}
