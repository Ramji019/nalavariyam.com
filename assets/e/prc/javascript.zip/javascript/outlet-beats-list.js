Ext.namespace('prc.outlet.beatslist');

var hanOutletBeatList = function(btn)
{
}
